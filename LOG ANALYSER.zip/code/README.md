# LOG ANALYSER

The access logs and error logs can both be analyzed with this Python script. The IP and the number of times it appeared in the log will be returned.



## How to use the Application: 
```
python3 ipcounter.py
```

### Prerequisites needed

This program can only be run with Python 3. There is a good chance that Python is already installed on your Linux distribution. Try the following commands in a terminal window to determine which version you have:
```
python3 --version

```
