# pseudocode
# define the log file and input the file location for the log file, create a loopback for the internet protocol, output for the header is printed, the header is printed for better output, there is initialization of the internet protocol count, the counter is defined, the output is printed using string format.


import collections
import sys
import os

#LogFile location Input from the End User
LogFile = input("Enter the full path of the Log file which needs to be analysed: ")

# This will exclude the Loopback IP Address both in IPV4 and IPV6
EXCLUDES = ('127.0.0.1','::1')

#Output Header for better readability
print('{:15}  : {}'.format("IP","COUNT"))

# Initialise the IP Counter collections
ipCounter = collections.Counter()

with open(LogFile,'r') as fobj:
  for logLine in fobj:
      ip = logLine.split()[0]
      if ip not in EXCLUDES:
          ipCounter.update((ip,))
      
# Print Output using Sting Formatting
for ip,count in ipCounter.most_common(5):
  print('{:15}  : {}'.format(ip,count))
