
package johndoeprimepath;

public class Constants {
    
    public static final String SAMPLE_GRAPH = "Nodes: [0,1,2,3,4,5,6]\n"
            + "InitNodes: [0]\n"
            + "EndNodes: [6]\n"
            + "Edges:\n"
            + "0 to [1,4]\n"
            + "1 to [2,5]\n"
            + "2 to [3]\n"
            + "3 to [1]\n"
            + "4 to [4,6]\n"
            + "5 to [6]\n"
            + "6 to [-1]";
    
    public static final String ENTER_GRAPH_LABEL_TEXT = "Graph Details:";

    public static final String OUTPUT_LABEL_TEXT = "Prime Paths Output:";

    public static final String STATUS_LABEL_TEXT = "Prime Path Status:";

    public static final String GENERATE_BUTTON_TEXT = "Generate";

    public static final String TO_STRING_SMALL = "to";
    public static final String NODES_STRING_SMALL = "nodes";
    public static final String INIT_NODES_STRING_SMALL = "initnodes";
    public static final String END_NODES_STRING_SMALL = "endnodes";
    public static final String EDGES_STRING_SMALL = "edges";
       
}
