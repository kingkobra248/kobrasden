
package johndoeprimepath;
import java.util.ArrayList;
import java.util.List;

public class Graph {
    
    public List<Node> nodes = new ArrayList<Node>() ;
    public List<Node> initNodes = new ArrayList<>();
    public List<Node> endNodes = new ArrayList<Node>();
    
    /**
     * add a directed graph edge from Nodes pathid1 to pathid2
     */
    public boolean addEdge(int pathid1, int pathid2) {
        if(pathid2 < 0)
            return true;
            
        Node a  = null;
        Node b  = null;
        for(Node n : nodes) {
            if(n.pathid == pathid1)
                a = n;
            if(n.pathid == pathid2)
                b = n;
        }
        if(a == null || b == null)
            return false;
        a.nextNodes.add(b);
        return true;
    }
}

