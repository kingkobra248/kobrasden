
package johndoeprimepath;
import java.util.List;

public class JohnDoePrimePath {

    private static MainForm p;
    
    public static void main(String[] args) {
        p = new MainForm();
        p.createUI();
    }

    public static void generatePrimePath(String text) {
        p.setOutputText("");
        p.setStatusText("");
        String [] sp = text.split("\n");
        String [] err = new String[2];
        err[0] = null;
        err[1] = "";
        Graph g = ParseUtil.parseGraph(sp, err);
        if(g == null || err[0]!= null) {
            p.setOutputText("");
            p.setStatusText("Error while creating graph:\n" + err[0]);
            return;
        }
        
        List<Paths> ff = PrimePath.generatePrimePaths(g);
        String str = getOutput(ff);
        p.setOutputText(str);
        p.setStatusText("Prime Path generated successfully.\n");
        if(err[1].trim().length()>0) {
            p.setStatusText("\n\n***********************************\nWarnings:\n***********************************\n" + err[1] + "\n\n");
        } else
            p.setStatusText("Prime path generated successfully.");
        
        System.out.println("");
        
    }
    
    /**
     * Generate output string from a list of prime paths
     */
    private static String getOutput(List<Paths> ff) {
        StringBuilder sb = new StringBuilder();
        sb.append("Prime Paths of this graph(" + ff.size() + "):");
        sb.append(System.getProperty("line.separator"));
        for(int i=0;i<ff.size();i++) {
            Paths p = ff.get(i);
            sb.append("Path " + (i+1) + ": (" + p.getNodes().get(0).pathid);
            for(int j=1;j<p.getNodes().size();j++)
                sb.append(", " + p.getNodes().get(j).pathid);
            sb.append(")");
            sb.append(System.getProperty("line.separator"));
        }
        return sb.toString();
    }

}
