
package johndoeprimepath;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

public class MainForm {
 
    private JFrame mainFormFrame;

    private JTextArea inputTextArea;
    private JTextArea outputTextArea;
    private JTextArea statusTextArea;
    private JButton goButton;

    public void createUI() {
        mainFormFrame = new JFrame();
        addLabel(mainFormFrame, Constants.ENTER_GRAPH_LABEL_TEXT, 10,
                10, 300, 30);
        addLabel(mainFormFrame, Constants.OUTPUT_LABEL_TEXT, 330, 10,
                300, 30);
        addLabel(mainFormFrame, Constants.STATUS_LABEL_TEXT, 660, 110,
                300, 30);
        int h = 300;
        int w = 300;
        inputTextArea = addTextArea(mainFormFrame,
                Constants.SAMPLE_GRAPH, 10, 50, w, h);
        outputTextArea = addTextArea(mainFormFrame, "", 330, 50, w, h);
        statusTextArea = addTextArea(mainFormFrame, "", 660, 150, w,
                h - 100);
        goButton = addButton(mainFormFrame,
                Constants.GENERATE_BUTTON_TEXT, 660, 20, w, 30);

        // generate prime path on button click
        goButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JohnDoePrimePath
                        .generatePrimePath(inputTextArea.getText());
            }
        });
        mainFormFrame.setSize(1000, 500);
        mainFormFrame.setLayout(null);
        mainFormFrame.setVisible(true);
    }

    public void setOutputText(String arg) {
        this.outputTextArea.setText(arg);
    }

    public void setStatusText(String arg) {
        this.statusTextArea.setText(arg);
    }

    private JLabel addLabel(JFrame mainForm, String text, int x, int y,
            int wid, int hei) {
        JLabel label = new JLabel(text);
        label.setBounds(x, y, wid, hei);
        mainForm.add(label);
        return label;
    }

    private JTextArea addTextArea(JFrame mainForm, String text, int x,
            int y, int wid, int hei) {
        JTextArea textArea = new JTextArea(text);
        textArea.setLineWrap(true);
        textArea.setBounds(x, y, wid, hei);
        mainForm.add(textArea);
        return textArea;
    }

    private JButton addButton(JFrame mainForm, String text, int x,
            int y, int w, int h) {
        JButton btn = new JButton(text);
        btn.setBounds(x, y, w, h);
        mainForm.add(btn);
        return btn;
    }
}

