
package johndoeprimepath;
import java.util.ArrayList;
import java.util.List;

public class Node {
    
        public int pathid;
    public List<Node> nextNodes= new ArrayList<Node>();
    
    public Node(int pathid) {
        this.pathid= pathid;
    }
}

