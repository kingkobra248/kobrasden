
package johndoeprimepath;
import java.util.ArrayList;
import java.util.List;

public class ParseUtil {

    public static Graph parseGraph(String[] lines, String[] error) {
        error[0] = null;
        error[1] = "";
        int i = 0;
        String nodesLine = null;
        String initNodesLine = null;
        String endNodesLine = null;
        List<String> edgeLines = new ArrayList<>();
        boolean isEdgeLine = false;
        for (i = 0; i < lines.length; i++) {
            String s = lines[i];
            if (isEmptyOrNull(s))
                continue;
            s = s.trim();
            if (isEdgeLine && s.contains(Constants.TO_STRING_SMALL)) {
                edgeLines.add(s);
            }
            if (isEdgeLine && s.length() > 0
                    && (!s.contains(Constants.TO_STRING_SMALL))) {
                isEdgeLine = false;
            }
            if (s.toLowerCase()
                    .startsWith(Constants.NODES_STRING_SMALL))
                nodesLine = s;
            if (s.toLowerCase()
                    .startsWith(Constants.INIT_NODES_STRING_SMALL))
                initNodesLine = s;
            if (s.toLowerCase()
                    .startsWith(Constants.END_NODES_STRING_SMALL))
                endNodesLine = s;
            if (s.toLowerCase()
                    .startsWith(Constants.EDGES_STRING_SMALL)) {
                isEdgeLine = true;
            }
        }

        Graph gg = new Graph();
        List<Integer> nVals = parseAfterColon(nodesLine, error);
        if (error[0] != null) {
            return null;
        }
        for (int val : nVals) {
            Node n = new Node(val);
            if (val >= 0)
                gg.nodes.add(n);
            else
                error[1] += "Invalid node id while adding node: " + val;
        }

        addInitialOrFinalNode(gg.nodes, gg.initNodes, initNodesLine,
                "initial", error);
        if (error[0] != null)
            return null;

        addInitialOrFinalNode(gg.nodes, gg.endNodes, endNodesLine, "end",
                error);
        if (error[0] != null)
            return null;

        for (String s : edgeLines) {
            addEdges(gg, s, error);
            if (error[0] != null)
                return null;
        }
        return gg;
    }

    /**
     * parse string to add Initial or End Node
     */
    private static void addInitialOrFinalNode(List<Node> allNodes,
            List<Node> initEndList, String initNodesLine,
            String typeString, String[] error) {
        List<Integer> iVals = parseAfterColon(initNodesLine, error);
        if (error[0] != null)
            return;
        for (int val : iVals) {
            Node add = null;
            for (Node n : allNodes)
                if (n.pathid == val)
                    add = n;
            if (add != null)
                initEndList.add(add);
            else {
                error[1] += "Invalid " + typeString
                        + " node id while adding " + typeString
                        + " nodes: " + val;
            }
        }

    }

    
    private static void addEdges(Graph g, String lineArg,
            String[] errorWarning) {
        errorWarning[0] = null;
        String line = lineArg.trim();
        if (!line.contains("to"))
            return;
        int ind = line.indexOf("to");
        String s1 = line.substring(0, ind);
        String s2 = line.substring(ind + 2);
        s1 = s1.trim();
        s2 = s2.trim();
        int sourceId = 0;
        try {
            sourceId = Integer.parseInt(s1);
        } catch (Exception ex) {
            errorWarning[0] = "Error in addEdges - invalid integer "
                    + s1 + " while parsing line: " + line;
            return;
        }

        ArrayList<Integer> dests = parseIntegersList(s2, errorWarning);
        if (!isEmptyOrNull(errorWarning[0])) {
            return;
        }

        for (int i = 0; i < dests.size(); i++) {
            boolean b = g.addEdge(sourceId, dests.get(i));
            if (!b)
                errorWarning[1] += "Warning: Invalid addition of graph edge - "
                        + sourceId + ", " + dests.get(i) + " in line "
                        + lineArg;
        }
    }

    public static boolean isEmptyOrNull(String s) {
        if (s == null)
            return true;
        if (s.trim().length() == 0)
            return true;
        return false;
    }

    public static ArrayList<Integer> parseAfterColon(String line,
            String[] errorWarning) {
        errorWarning[0] = null;
        if (!line.contains(":")) {
            errorWarning[0] = "Error in parseAfterColon while parsing line: "
                    + line;
            return null;
        }
        String[] split = line.split(":");
        if (split.length < 2)
            return new ArrayList<Integer>();

        String s = split[1].trim();
        if (s.length() == 0)
            return new ArrayList<Integer>();
        return parseIntegersList(s, errorWarning);
    }

    private static ArrayList<Integer> parseIntegersList(String s,
            String[] error) {
        ArrayList<Integer> ret = new ArrayList<Integer>();
        error[0] = null;

        if (!s.startsWith("[") || !s.endsWith("]")) {
            error[0] = "Error in parseIntegersList parsing : " + s;
            return null;
        }

        s = s.substring(1, s.length() - 1);
        String[] sp2 = s.split(",");
        for (String val : sp2) {
            String v = val.trim();
            if (v.length() > 0) {
                try {
                    int add = Integer.parseInt(v);
                    ret.add(add);
                } catch (Exception ex) {
                    error[0] = "Error in parseIntegersList - invalid integer "
                            + v + " while parsing: " + s;
                    return null;
                }
            }
        }
        return ret;
    }
}
