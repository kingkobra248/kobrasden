
package johndoeprimepath;
import java.util.ArrayList;
import java.util.List;

public class Paths {
  
// list of nodes in path
    private List<Node> nodes = new ArrayList<Node>();
    
    public Paths(Node head) {
        this.nodes.add(head);    
    }
    
    
    public boolean isDeadEnd( ) {
        return this.nodes.get(this.nodes.size()-1).nextNodes.size() == 0;
    }
    
    /**
     * if start and end nodes are same.
     */
    public boolean isStar() {
        return this.nodes.size()>1 && (this.nodes.get(0).pathid == this.nodes.get(this.nodes.size()-1).pathid);
    }
    
    public int getLength() {
        return nodes.size();
    }
    
    public List<Node> getNodes() {
        return nodes;
    }
    
    public Paths copy() {
        Paths ret = new Paths(this.nodes.get(0));
        for(int i=1;i<this.nodes.size();i++)
            ret.nodes.add(this.nodes.get(i));
        return ret;
    }
}

