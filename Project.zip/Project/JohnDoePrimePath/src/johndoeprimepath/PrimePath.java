
package johndoeprimepath;
import java.util.ArrayList;
import java.util.List;

public class PrimePath {
  
    public static List<Paths> generatePrimePaths(Graph g) {
        List<Paths> sPaths = generateSimplePaths(g);
        List<Paths> pPaths = filterPrimePaths(sPaths);
        return pPaths;
    }
    
    /**
     * Generate a list of all simple paths in graph 
     */
    private static List<Paths> generateSimplePaths(Graph g) {
        ArrayList<Paths> ret = new ArrayList<Paths>();
        for(Node n : g.nodes) {
            ret.add(new Paths(n));
        }
        
        int done = 0;
        int till = ret.size();
        while(done!= till) {
            for(int i=done; i<till;i++) {
               Paths currentPath = ret.get(i);
               if(currentPath.isStar()) continue;
               Node last = currentPath.getNodes().get(currentPath.getNodes().size()-1);
               for(Node n : last.nextNodes) {
                   boolean skip = false;
                   for(int j=1;j<currentPath.getNodes().size();j++)
                       if(currentPath.getNodes().get(j).pathid == n.pathid)
                           skip = true;
                   if(skip)
                       continue;
                  Paths pth = currentPath.copy();
                  pth.getNodes().add(n); 
                  ret.add(pth);
               }
            }
            done = till;
            till = ret.size();
        }
        return ret;
    }

    /**
     * Filter prime paths from list of simple paths
     */
    private static List<Paths> filterPrimePaths(List<Paths> arg) {
        boolean [] isSubPath = new boolean[arg.size()];
        for(int i=0;i<isSubPath.length;i++)
            isSubPath[i] = false;
        
        for(int i=arg.size()-1;i>=0;i--) {
            for(int j=0;j<arg.size();j++) {
                if(i==j) continue;
                if(isSubPath[j]) continue;
                Paths ch = arg.get(i);
                Paths par = arg.get(j);
                if(ch.getNodes().size() >= par.getNodes().size())
                    continue;
                int diff = par.getNodes().size() - ch.getNodes().size();
                for(int k=0;k<diff+1;k++) {
                    boolean isSubset = true;
                    for(int m=0;m<ch.getNodes().size();m++) {
                        if(ch.getNodes().get(m).pathid != par.getNodes().get(k+m).pathid) {
                            isSubset = false;
                            break;
                        }
                    }
                    if(isSubset)
                        isSubPath[i] = true;
                }
                
            }
        }
        
        List<Paths> ret = new ArrayList<Paths>();
        for(int i=0;i<arg.size();i++)
            if(!isSubPath[i])
                ret.add(arg.get(i));
        return ret;
    }
}

