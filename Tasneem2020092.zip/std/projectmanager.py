# IMPORT MODULE FOR PATTERN MATCHING
import re
# IMPORT MODULE FOR SYSTEM OPERATIONS
import sys

# THIS FUNCTION COLLECTS USER INPUTS AND WRITES THE VALIDATED DATA TO A TEXT FILE
def input_project_details():
    lst = []
    while True:
        # I USED TRY EXCEPTION BLOCKS TO CATCH ERRORS AND PREVENT PROGRAM FAILURE
        try:
            ID = int(input("[+ Enter PRoject ID +]"))
            # CHECK THAT ID IS A NUMBER AND NOT EMPTY
            if isinstance(ID,int) & ID !='':
                lst.append(ID)
                break
        except ValueError:
            print("Value passed is not an integer/number!!try again")
            continue
    while True:
        try:
            Title=input("[+ ENter Project Title+]")

            # CHECK THAT TITLE IS NOT EMPTY
            if Title != '':
                lst.append(Title)
                break
        except ValueError:
            print("Provide a Value")
            continue
    while True:
        try:
            Size=int(input("[+ ENter No Of Pages +]"))
            # CHECK THAT SIZE IS NOT EMPTY AND IS A NUMBER
            if isinstance(Size,int) & Size !='':
                lst.append(Size)
                break
        except ValueError:
            print("Value passed is not an integer/number!!try again")
            continue
    while True:
        try:
            contact_names=input("[+ ENter name of project owner +]")
            # CHECK THAT CONTACT NAME IS NOT EMPTY
            if contact_names != '':
                lst.append(contact_names)
                break
        except ValueError:
            print("Provide a Value")
            continue
    while True:
        try:
            contact_phone=input("[+ Enter Phone number +]")
            # CHECK THAT CONTACT PHONE EQUAL TO 10 DIGITS AND CONTAINS DIGITS ONLY
            if  contact_phone.isnumeric() & (len(contact_phone)==10):
                lst.append(contact_phone)
                break
        except ValueError:
            print("Provide a Value")
            continue
    while True:
        try:
            contact_Email=input("[+ ENter Mail]")
            # I USED REGEX TO PERFORM PATTERN MATHING AND ENSURED EMAIL VALIDITY
            email_pattern = "^[a-zA-Z0-9-_]+@[a-zA-Z0-9]+\.com$"
            if re.match(email_pattern, contact_Email):
                lst.append(contact_Email)
                break
        except ValueError:
            print("Provide a Valid mail address")
            continue
    while True:
        try:
            status=int(input("[+ ENter status 1(DONE) 0(UN_DONE )+]"))
            # ENURE STATUS IS A NUMBER BETWEEN 0 AND 1

            if isinstance(status, int) & (status == 1 or status ==0):
                lst.append(status)
                break
        except ValueError:
            print("Value passed is not an integer/number!!try again")
            continue
    with open('projects.txt','a') as file:
        file.write(f'{ID} ,{Title} ,{Size}, {contact_names} ,{contact_phone}, {contact_Email}, {status}')
        file.write('\n')
#


# THIS METHOD RETURNS A PROJECT WITH THE PASSED ID FROM USER INPUT
def one_project():
    while True:
        project_id = (input("Enter Project Id youll wish to view "))
        for data in open('projects.txt','r') :
            line = data.split(",")
            if project_id in line:

                print(line)
                break
            else:
                continue
# THIS METHOD RETURNS THE TOTAL NUMBER OF COMPLETED PROJECTS (WHERE STATUS=0)
def completed_projects():
    status = '0'
    for data in open('projects.txt', 'r'):
        line = data.split(",")
        if status in line[-1]:
            print(len(line))
            break
# THIS METHOD RETURNS ALL PROJECTS ,TOTAL NUMBER OF PROJECTS AND TOTAL NUMBER OF COMPLETED PROJECTS
def all_projects():
    ct=0
    for data in open('projects.txt', 'r'):
        line = data.split(",")
        print(data)
    print(f"Total Number of Projects :{len(line)-1}")
    for status in line[-1]:
        ct+=1
        continue
    print(f"Total Number of Completed Projects :{ct}")

# THIS FUNCTIONS AUTOMATICALLY SCHEDULES A PROJECT AND CREATES A LIST
def create_schedule():
    word='0'
    sched=[]
    with open('projects.txt', 'r') as fp:
        # read all lines in a list
        lines = fp.readlines()
        c=0
        for line in lines:
            # check if string present on a current line
            c+=1
            if line.find(word) != -1:
                line=line.strip('\n')
                # print(c)
                sched.append(f"{c} , {line}")
        # print(f"Updated Schedule [+ {sched} +]")
    print(lines)
    return lines
# THIS FUNCTION UPDATES A SCHEDULE AND UPDATES THE TEXT FILE
def update_schedule():
    line=create_schedule()
    for x in line:
        with open(r'projects.txt', 'a') as fp:
            px=x
            fp.write(x)
        break
    print(x)
    with open('projects.txt','r') as file:
        file=file.readlines()
    with open('projects.txt','w') as pg:
        x=str(x)
        x=x.replace('0','1')
        pg.seek(0)
        pg.write(x)
    for li in line:
        with open('projects.txt', 'a') as pg:
            pg.write(li)
    return px
# THIS FUNCTION RETURNS THE LATEST UPDATED ENTRY
def view_updated_schedule():
    with open('projects.txt', 'r') as pg:
        latest=pg.readline()
        print(f"latest updated project is {latest}")
        return latest

def exit_from_program():
    sys.exit()
def menu():
    # REQUEST USER INPUT UNTILL USER CLOSES THE PROGRAM
    while True:
        print ("""
        LIST OF DOABLE OPERATIONS
        1.Input Project Details
        2.View projects
        3.Schedule projects
        4.Quit
        """)
        module=input("ENTER THE OPERATION YOU WANT TO PERFORM")
        if module=="1":
            print("[+ CREATE PROJECTS +]")
            print("ENTER DETAILS CORRECTLY")
            input_project_details()
        elif module=="2":
            print ("""
        [+ VIEW PROJECT +]
        a.One project
        b.Complete project
        c.All project
        d.Exit
        """)
            operation= input("Choose an option from the following: ")
            if operation=="a":
                one_project()
            elif operation=="b":
                completed_projects()

            elif operation=="c":
                all_projects()
            elif operation== "d":
                menu()
            else:
                print("Wrong choice")

        elif module=="3":
          print("\n Schedule projects")
          print ("""
          [+ MANIPULATE PROJECT +]
        a.create a schedule
        b.update a schedule
        c.view latest schedule update
        d.Exit
        """)
        opt3= input("Choose an option from the following: ")
        if opt3=="a":
            create_schedule()
        elif opt3=="b":
            update_schedule()
        elif opt3=="c":
            view_updated_schedule()
        elif opt3== "d":
            menu()
        elif module=="4":
            exit_from_program()
        else:
            print("[+ !!INVALID INPUT +]")

menu()

# "1644 , Python, 44, mr Aron, 1122334455, notest@gmail.com, 0
# 1738, Java, 66, si james, 7788991122, test@gmail.com, 0
# 1622, C++, 21, kevin G ,1188776611 ,ddd@gmail.com, 1
# 1501, Go, 33, siri, 1122334455, yy@gmail.com, 0
# 242, grgr, 44, grgrgrg, 1212121212, da@gmail.com ,0
# 23, t44egd, 33, ffdrf, 1212121212, fff@gmail.com, 1"