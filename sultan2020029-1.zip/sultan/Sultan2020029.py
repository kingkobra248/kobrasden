# IMPORT MODULE FOR PATTERN MATCHING
import re
# IMPORT MODULE FOR SYSTEM OPERATIONS
import sys

# RQUEST FOR USER INPUTS
def register_project():
    buffer = []
    while True:
        # I USED TRY EXCEPTION BLOCKS TO CATCH ERRORS AND PREVENT PROGRAM FAILURE
        try:
            project_id = int(input(" enter project id "))
            # CHECK THAT ID IS A NUMBER AND NOT EMPTY
            if isinstance(project_id,int) & project_id !='':
                buffer.append(project_id)
                break
        except :
            print("enter valid input")
            continue
    while True:
        try:
            project_title=input(" enter project title  ")

            # CHECK THAT TITLE IS NOT EMPTY
            if project_title != '':
                buffer.append(project_title)
                break
        except :
            print("Provide a Value")
            continue
    while True:
        try:
            no_of_pages=int(input(" input number of pages "))
            # CHECK THAT TOTAL PAGES  IS A NUMBER
            if isinstance(no_of_pages,int) :
                buffer.append(no_of_pages)
                break
        except :
            print("invalid value")
            continue
    while True:
        try:
            names=input("input owners name")
            # CHECK THAT CONTACT NAME IS NOT EMPTY
            if names != '':
                buffer.append(names)
                break
        except :
            print("Provide a Value")
            continue
    while True:
        try:
            phone_no=input("input phone number")
            # CHECK THAT CONTACT PHONE  CONTAINS DIGITS ONLY
            if  phone_no.isnumeric() :
                buffer.append(phone_no)
                break
        except ValueError:
            print("Provide a Value")
            continue
    while True:
        try:
            email=input("input email")
            # I USED REGEX TO PERFORM PATTERN MATHING AND ENSURED EMAIL VALIDITY
            order = "^[a-zA-Z0-9-_]+@[a-zA-Z0-9]+\.com$"
            if re.match(order, email):
                buffer.append(email)
                break
        except :
            print("invalid email")
            continue
    while True:
        try:
            status=int(input("[+ ENter status 1(DONE) 0(UN_DONE )+]"))
            # ENURE STATUS IS A NUMBER BETWEEN 0 AND 1

            if isinstance(status, int) & (status == 1 or status ==0):
                buffer.append(status)
                break
        except :
            print("invalid input")
            continue
    with open('sultan.txt','a') as file:
        file.write(f'{project_id} ,{project_title} ,{no_of_pages}, {names} ,{phone_no}, {email}, {status}')
        file.write('\n')
#


# SEARCH FOR A PROJECT FROM THE TXT FILE BY PROJECT ID
def get_one_project():
    while True:
        project_id = (input("input id for searching"))
        for project_info in open('sultan.txt','r') :
            results = project_info.split(",")
            if project_id in results:
                print(results)
                break #BREAK TO RETURN THE FIRST INSTANCE
            else:
                continue

#RETURNS THE TOTAL NUMBER OF COMPLETED PROJECTS STATUS='0'
def get_done_projects():
    status = '0'
    for result in open('sultan.txt', 'r'):
        line = result.split(",")
        if status in line[-1]:
            print(f"TOTAL NUMBER OF COMPLETED JOBS {len(line)} ")
            break
# get_done_projects()
# THIS METHOD RETURNS ALL PROJECTS ,TOTAL NUMBER OF PROJECTS AND TOTAL NUMBER OF COMPLETED PROJECTS
def get_projects_info():
    counter=0
    for result in open('sultan.txt', 'r'):
        line = result.split(",")
        print(result)
    print(f"Total Number of Projects :{len(line)-1}")
    for status in line[-1]:
        counter+=1
        continue
    print(f"completed projects :{counter}")

# SCHEDULE A PROJECT
def create_schedule():
    status='0'
    work=[]
    with open('sultan.txt', 'r') as fp:
        # read all lines in a list
        result = fp.readlines()
        instance=0
        for results in result:
            # check if string present on a current line
            instance+=1
            if results.find(status) != -1:
                work.append(f"{instance} , {results}")
    print(result)
    return result
# create_schedule()
# UPDATE A SCHEDULE AND  THE TEXT FILE
def update_job_schedule():
    results=create_schedule()
    for x in results:
        with open(r'sultan.txt', 'a') as fp:
            updates=x
            fp.write(x)
        break
    print(x)
    with open('sultan.txt','r') as file:
        file=file.readlines()
    with open('sultan.txt','w') as pg:
        x=str(x)
        x=x.replace('0','1')
        pg.seek(0)
        pg.write(x)
    for result in results:
        with open('sultan.txt', 'a') as pg:
            pg.write(result)
    return updates
# update_job_schedule()
# PRINT LATES UPDATE
def view_updated_schedule():
    with open('sultan.txt', 'r') as pg:
        seek_top=pg.readline()
        print(f"latest updated project is {seek_top}")
        return seek_top
# view_updated_schedule()
def Quit():
    sys.exit()
while __name__=='__main__':


    print (" CHOICES \n 1.Input Project Details \n 2.View projects \n 3.Schedule projects \n 4.Quit ")
    option=input("ENTER THE OPERATION YOU WANT TO PERFORM")
    if option=="1":
        print("[+ CREATE PROJECTS +]")
        print("ENTER DETAILS CORRECTLY")
        register_project()
    elif option=="2":
        print ("  a.get one project b.get completed projects c.project details   d.Exit")
        operation= input("Choose an option from the following: ")
        if operation=="a":
            get_one_project()
        elif operation=="b":
            get_done_projects()

        elif operation=="c":
            get_projects_info()
        elif operation== "d":
            break
        else:
            print("Wrong choice")

    elif option=="3":
        print("schedule projects")
        print (" a.create a schedule \n b.update a schedule \n c.view latest schedule update \n d.close ")
        choice= input("select an option ")
        if choice=="a":
            create_schedule()
        elif choice=="b":
            update_job_schedule()
        elif choice=="c":
            view_updated_schedule()
        elif choice== "d":
            continue
    elif option=="4":
        Quit()
    else:
        print("error")



# "1644 , Python, 44, mr Aron, 1122334455, notest@gmail.com, 0
# 1738, Java, 66, si james, 7788991122, test@gmail.com, 0
# 1622, C++, 21, kevin G ,1188776611 ,ddd@gmail.com, 1
# 1501, Go, 33, siri, 1122334455, yy@gmail.com, 0
# 242, grgr, 44, grgrgrg, 1212121212, da@gmail.com ,0
# 23, t44egd, 33, ffdrf, 1212121212, fff@gmail.com, 1"